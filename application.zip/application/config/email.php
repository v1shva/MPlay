<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: Vishva
 * Date: 11/30/2016
 * Time: 2:10 PM
 */

$config['protocol'] = 'smtp';
$config['smtp_port'] = '587';
$config['smtp_host'] = 'smtp.sendgrid.net';
$config['smtp_user'] = 'mplaymail';
$config['smtp_pass'] = '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';
$config['smtp_port'] = '587';
$config['crlf'] = "\r\n";
$config['newline'] = "\r\n";

